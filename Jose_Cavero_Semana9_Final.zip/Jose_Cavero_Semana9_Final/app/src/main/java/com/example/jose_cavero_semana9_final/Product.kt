package com.example.jose_cavero_semana9_final

data class Product(
    val id: Int? = null,
    val title: String,
    val price: Double,
    val description: String,
    val category: String,
    val image: String,
    val rating: Float
)

