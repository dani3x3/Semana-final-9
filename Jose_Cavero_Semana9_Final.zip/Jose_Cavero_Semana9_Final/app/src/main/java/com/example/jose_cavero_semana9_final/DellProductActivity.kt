package com.example.jose_cavero_semana9_final

import android.view.View
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DellProductActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ProductAdapter
    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dell_product)

        // Initialize DBHelper
        dbHelper = DBHelper(this)

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerViewDell)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ProductAdapter(emptyList())
        recyclerView.adapter = adapter

        // Set click listener for RecyclerView items
        adapter.setOnItemClickListener(object : ProductAdapter.OnItemClickListener {
            override fun onItemClick(position: Int) {
                // Retrieve the product at the clicked position
                val product = adapter.getProductAtPosition(position)

                // Delete the product from the database if the ID is not null
                product.id?.let { productId ->
                    dbHelper.deleteProduct(productId)
                    // Remove the product from the RecyclerView
                    adapter.removeProductAt(position)
                }
            }
        })

        // Get all products from the database
        val productList = dbHelper.getAllProducts()

        // Update RecyclerView with product list
        adapter.updateProducts(productList)
    }

    // Define onDeleteButtonClick function
    fun onDeleteButtonClick(view: View) {
        // Implement the logic for deleting products here
    }
}

