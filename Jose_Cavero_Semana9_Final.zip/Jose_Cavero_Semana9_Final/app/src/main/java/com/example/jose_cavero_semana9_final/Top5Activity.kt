package com.example.jose_cavero_semana9_final



import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Top5Activity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ProductAdapter
    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_top5)

        // Inicializar vistas
        recyclerView = findViewById(R.id.recyclerViewTop5)

        // Configurar RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ProductAdapter(emptyList())
        recyclerView.adapter = adapter

        // Inicializar DBHelper
        dbHelper = DBHelper(this)

        // Obtener los 5 productos mejor valorados
        val top5Products = getTop5Products()
        adapter.updateProducts(top5Products)
    }

    private fun getTop5Products(): List<Product> {
        // Aquí se obtienen los 5 productos mejor valorados de DBHelper
        return dbHelper.getTopRatedProducts(5)
    }
}
