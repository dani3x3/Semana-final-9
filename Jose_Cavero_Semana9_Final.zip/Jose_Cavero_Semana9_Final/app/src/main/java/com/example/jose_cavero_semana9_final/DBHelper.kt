package com.example.jose_cavero_semana9_final


import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "ProductsDB"
        const val TABLE_PRODUCTS = "products"
        const val KEY_ID = "id"
        const val KEY_TITLE = "title"
        const val KEY_PRICE = "price"
        const val KEY_DESCRIPTION = "description"
        const val KEY_CATEGORY = "category"
        const val KEY_IMAGE = "image"
        const val KEY_RATING = "rating"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        // Crear la tabla de productos
        val createTableQuery = ("CREATE TABLE $TABLE_PRODUCTS ($KEY_ID INTEGER PRIMARY KEY, "
                + "$KEY_TITLE TEXT, "
                + "$KEY_PRICE REAL, "
                + "$KEY_DESCRIPTION TEXT, "
                + "$KEY_CATEGORY TEXT, "
                + "$KEY_IMAGE TEXT, "  // Changed to TEXT type for storing URL
                + "$KEY_RATING REAL)")
        db?.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Eliminar la tabla anterior si existe y crear una nueva
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_PRODUCTS")
        onCreate(db)
    }

    fun insertProduct(product: Product): Long {
        // Insertar un nuevo producto en la base de datos
        val db = writableDatabase
        val values = ContentValues().apply {
            put(KEY_TITLE, product.title)
            put(KEY_PRICE, product.price.toFloat()) // Convertir Double a Float
            put(KEY_DESCRIPTION, product.description)
            put(KEY_CATEGORY, product.category)
            put(KEY_IMAGE, product.image) // Store the image URL as String
            put(KEY_RATING, product.rating)
        }
        return db.insert(TABLE_PRODUCTS, null, values)
    }

    fun getAllProducts(): List<Product> {
        // Obtener todos los productos de la base de datos
        val productList = mutableListOf<Product>()
        val db = readableDatabase
        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_PRODUCTS", null)
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndex(KEY_ID))
                val title = cursor.getString(cursor.getColumnIndex(KEY_TITLE))
                val price = cursor.getDouble(cursor.getColumnIndex(KEY_PRICE))
                val description = cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION))
                val category = cursor.getString(cursor.getColumnIndex(KEY_CATEGORY))
                val image = cursor.getString(cursor.getColumnIndex(KEY_IMAGE)) // Retrieve image URL as String
                val rating = cursor.getFloat(cursor.getColumnIndex(KEY_RATING))
                val product = Product(id, title, price, description, category, image, rating)
                productList.add(product)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return productList
    }

    fun deleteProduct(productId: Int): Int {
        // Eliminar un producto de la base de datos
        val db = writableDatabase
        return db.delete(TABLE_PRODUCTS, "$KEY_ID=?", arrayOf(productId.toString()))
    }

    fun getTopRatedProducts(limit: Int = 5): List<Product> {
        // Obtener los productos mejor calificados de la base de datos
        val productList = mutableListOf<Product>()
        val db = readableDatabase
        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_PRODUCTS ORDER BY $KEY_RATING DESC LIMIT $limit", null)
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndex(KEY_ID))
                val title = cursor.getString(cursor.getColumnIndex(KEY_TITLE))
                val price = cursor.getDouble(cursor.getColumnIndex(KEY_PRICE))
                val description = cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION))
                val category = cursor.getString(cursor.getColumnIndex(KEY_CATEGORY))
                val image = cursor.getString(cursor.getColumnIndex(KEY_IMAGE)) // Retrieve image URL as String
                val rating = cursor.getFloat(cursor.getColumnIndex(KEY_RATING))
                val product = Product(id, title, price, description, category, image, rating)
                productList.add(product)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return productList
    }
}


