package com.example.jose_cavero_semana9_final


import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ProductAdapter
    private lateinit var updateButton: Button
    private lateinit var top5Button: Button
    private lateinit var addProductButton: Button
    private lateinit var deleteProductButton: Button
    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        recyclerView = findViewById(R.id.recyclerView)
        updateButton = findViewById(R.id.updateButton)
        top5Button = findViewById(R.id.top5Button)
        addProductButton = findViewById(R.id.addProductButton)
        deleteProductButton = findViewById(R.id.deleteProductButton)

        // Set up RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ProductAdapter(emptyList())
        recyclerView.adapter = adapter

        // Set up button click listeners
        updateButton.setOnClickListener {
            // Load data from database
            loadProductsFromDatabase()
        }

        top5Button.setOnClickListener {
            val intent = Intent(this, Top5Activity::class.java)
            startActivity(intent)
        }

        addProductButton.setOnClickListener {
            val intent = Intent(this, AddProductActivity::class.java)
            startActivity(intent)
        }

        deleteProductButton.setOnClickListener {
            val intent = Intent(this, DellProductActivity::class.java)
            startActivity(intent)
        }

        // Initialize the database helper
        dbHelper = DBHelper(this)

        // Check if the database is empty, if so, download data and update the database
        if (dbHelper.getAllProducts().isEmpty()) {
            downloadDataAndUpdateDatabase()
        } else {
            // Populate RecyclerView with data from the database
            loadProductsFromDatabase()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.product_context_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_add_product -> {
                Log.d("MainActivity", "Add Product menu item clicked") // Agregar este mensaje de registro
                val intent = Intent(this, AddProductActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.action_delete_product -> {
                val intent = Intent(this, DellProductActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun downloadDataAndUpdateDatabase() {
        GlobalScope.launch(Dispatchers.IO) {
            val url = URL("https://fakestoreapi.com/products")
            val urlConnection = url.openConnection() as HttpURLConnection
            try {
                val inputStream = urlConnection.inputStream
                val bufferedReader = BufferedReader(InputStreamReader(inputStream))
                val stringBuilder = StringBuilder()
                var line: String?
                while (bufferedReader.readLine().also { line = it } != null) {
                    stringBuilder.append(line)
                }
                bufferedReader.close()

                // Parse JSON response
                val jsonArray = JSONArray(stringBuilder.toString())
                val productList = mutableListOf<Product>()
                for (i in 0 until jsonArray.length()) {
                    val jsonObject = jsonArray.getJSONObject(i)
                    val id = jsonObject.getInt("id")
                    val title = jsonObject.getString("title")
                    val price = jsonObject.getDouble("price")
                    val description = jsonObject.getString("description")
                    val category = jsonObject.getString("category")
                    val ratingObject = jsonObject.getJSONObject("rating")
                    val image = jsonObject.getString("image")
                    val rating = ratingObject.getDouble("rate").toFloat() // Modificación aquí
                    val product = Product(id, title, price, description, category, image, rating)
                    productList.add(product)
                }

                // Update the database
                //dbHelper.deleteAllProducts()
                productList.forEach { product ->
                    dbHelper.insertProduct(product)
                }

                // Reverse the list order
                productList.reverse()

                // Update RecyclerView
                runOnUiThread {
                    adapter.updateProducts(productList)
                    Toast.makeText(this@MainActivity, "Productos cargados correctamente", Toast.LENGTH_SHORT).show()
                }
            } finally {
                urlConnection.disconnect()
            }
        }
    }

    private fun loadProductsFromDatabase() {
        GlobalScope.launch(Dispatchers.IO) {
            val productList = dbHelper.getAllProducts()

            // Update RecyclerView
            runOnUiThread {
                adapter.updateProducts(productList)
                if (productList.isNotEmpty()) {
                    Toast.makeText(this@MainActivity, "Productos cargados correctamente", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "La base de datos está vacía", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
