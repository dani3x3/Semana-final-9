package com.example.jose_cavero_semana9_final


import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddProductActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper
    private lateinit var titleEditText: EditText
    private lateinit var priceEditText: EditText
    private lateinit var descriptionEditText: EditText
    private lateinit var categoryEditText: EditText
    private lateinit var imageEditText: EditText
    private lateinit var ratingEditText: EditText
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)

        // Initialize DBHelper
        dbHelper = DBHelper(this)

        // Initialize views
        titleEditText = findViewById(R.id.editTextTitle)
        priceEditText = findViewById(R.id.editTextPrice)
        descriptionEditText = findViewById(R.id.editTextDescription)
        categoryEditText = findViewById(R.id.editTextCategory)
        imageEditText = findViewById(R.id.editTextImage)
        ratingEditText = findViewById(R.id.editTextRating)
        saveButton = findViewById(R.id.buttonAddProduct)

        // Set up save button click listener
        saveButton.setOnClickListener {
            saveProduct()
        }
    }

    private fun saveProduct() {
        val title = titleEditText.text.toString()
        val priceText = priceEditText.text.toString()
        val description = descriptionEditText.text.toString()
        val category = categoryEditText.text.toString()
        val image = imageEditText.text.toString()
        val ratingText = ratingEditText.text.toString()

        // Verificar si algún campo está vacío
        if (title.isEmpty() || priceText.isEmpty() || description.isEmpty() ||
            category.isEmpty() || image.isEmpty() || ratingText.isEmpty()) {
            // Mostrar mensaje de error
            Toast.makeText(this, "Por favor complete todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        // Convertir precio y valoración a tipos numéricos
        val price = priceText.toDoubleOrNull() ?: 0.0
        val rating = ratingText.toFloatOrNull() ?: 0.0f

        // Crear un objeto Product
        val product = Product(title = title, price = price, description = description,
            category = category, image = image, rating = rating)

        // Insertar el producto en la base de datos
        dbHelper.insertProduct(product)

        // Mostrar un mensaje indicando que el producto se ha guardado correctamente
        Toast.makeText(this, "Producto agregado correctamente", Toast.LENGTH_SHORT).show()

        // Finalizar la actividad para regresar a la pantalla anterior
        finish()
    }
}
