package com.example.jose_cavero_semana9_final

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ProductAdapter(private var productList: List<Product>) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    private var listener: OnItemClickListener? = null

    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.listener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val currentItem = productList[position]

        holder.titleTextView.text = currentItem.title
        holder.priceTextView.text = "$${currentItem.price}"
        holder.descriptionTextView.text = currentItem.description
        holder.categoryTextView.text = currentItem.category

        // Load the image using Glide
        Glide.with(holder.itemView)
            .load(currentItem.image)
            .into(holder.imageView)
        holder.ratingBar.rating = currentItem.rating

        // Set click listener for the product image to show the context menu
        holder.imageView.setOnClickListener { view ->
            val popupMenu = PopupMenu(view.context, view)
            popupMenu.menuInflater.inflate(R.menu.product_context_menu, popupMenu.menu)
            popupMenu.setOnMenuItemClickListener { menuItem ->
                when (menuItem.itemId) {
                    R.id.action_add_product -> {
                        // Implement action to add product
                        true
                    }
                    R.id.action_delete_product -> {
                        // Implement action to delete product
                        true
                    }
                    else -> false
                }
            }
            popupMenu.show()
        }

        // Set click listener for the whole item view
        holder.itemView.setOnClickListener {
            listener?.onItemClick(position)
        }
    }

    override fun getItemCount() = productList.size

    fun updateProducts(newProducts: List<Product>) {
        productList = newProducts
        notifyDataSetChanged()
    }

    fun getProductAtPosition(position: Int): Product {
        return productList[position]
    }

    fun removeProductAt(position: Int) {
        val mutableList = productList.toMutableList()
        mutableList.removeAt(position)
        productList = mutableList.toList()
        notifyItemRemoved(position)
    }

    class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.title)
        val priceTextView: TextView = itemView.findViewById(R.id.price)
        val descriptionTextView: TextView = itemView.findViewById(R.id.description)
        val categoryTextView: TextView = itemView.findViewById(R.id.category)
        val imageView: ImageView = itemView.findViewById(R.id.image)
        val ratingBar: RatingBar = itemView.findViewById(R.id.rating)
    }
}
